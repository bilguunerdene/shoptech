<script src="{{asset('js/jquery.min.js')}}"></script>
<script>
    
    
      
   </script>

   