<html>
    <head>

    </head>
    <body>
        Hi, Deliver date - {{$data['recdate']}} On branch #{{$data['branch']}}
    </body>
</html>